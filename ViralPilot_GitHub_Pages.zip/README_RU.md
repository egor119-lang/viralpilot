# ViralPilot — GitHub Pages

Рекомендуемое имя репозитория: `viralpilot`

Если GitHub username: `povstories-world`, URL будут:

- Главная: `https://povstories-world.github.io/viralpilot/`
- Terms: `https://povstories-world.github.io/viralpilot/terms.html`
- Privacy: `https://povstories-world.github.io/viralpilot/privacy.html`

## Загрузка
1. GitHub → New repository → имя `viralpilot` → Public.
2. Add file → Upload files.
3. Загрузить все файлы из архива в корень репозитория.
4. Commit changes.
5. Settings → Pages.
6. Source: Deploy from a branch.
7. Branch: `main`; folder: `/ (root)`.
8. Save и подождать публикацию.

## TikTok Developer
App icon: `viralpilot_icon_1024.png`

Terms of Service URL:
`https://povstories-world.github.io/viralpilot/terms.html`

Privacy Policy URL:
`https://povstories-world.github.io/viralpilot/privacy.html`

Web/Desktop URL:
`https://povstories-world.github.io/viralpilot/`

OAuth Redirect URI:
`http://127.0.0.1:8787/tiktok/callback/`

Если TikTok выдаст verification-файл, положите его в корень репозитория рядом с `index.html`, сделайте Commit, затем повторите Verify.
